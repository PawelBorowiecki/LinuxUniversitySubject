# Make hello documentation.				-*-Makefile-*-
# This is included by the top-level Makefile.am.

# Copyright (C) 1995-2026 Free Software Foundation, Inc.

# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.

# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.

# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <https://www.gnu.org/licenses/>.

info_TEXINFOS = doc/hello.texi

doc_hello_TEXINFOS = \
  doc/fdl.texi

# The customization variable CHECK_NORMAL_MENU_STRUCTURE is necessary with
# makeinfo versions ≥ 6.8.
AM_MAKEINFOFLAGS = -c CHECK_NORMAL_MENU_STRUCTURE=1
